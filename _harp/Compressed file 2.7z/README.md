HARP.js Styleguide
====================
This will provide a basic skeleton app for a web design styleguide. 

Currently very much WIP.

Usage
-----

* install [Node](http://nodejs.org/download/) `brew install node`
* install Harp.js `npm install -g harp`
* clone this repo somewhere
* cd into the project directory
* start the server with `harp server`
* edit pages object in `/_harp.json`
* add/edit/remove the various sections in each corresponding view
